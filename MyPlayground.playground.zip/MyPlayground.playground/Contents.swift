import Foundation
import UIKit
import Darwin
import CoreGraphics

//let banner = """
//          __,
//         (           o  /) _/_
//          `.  , , , ,  //  /
//        (___)(_(_/_(_ //_ (__
//                     /)
//                    (/
//        """
//print(banner)


//func finder (numberInt: Int) -> Int? {
//    if numberInt % 7 == 0 {
//        return numberInt;
//    } else {
//        return nil;
//    }
//}
//
//let array1 = [0 , -63, 54, 7, 49, -49, 70, 6];
//
//for i in array1 {
//    let found = finder(numberInt: i)
//    print(found)
//}
//
//let simpleClosure: (String) -> (String) = {
//    name in
//
//    return "\(name) world"
//}
//
//simpleClosure("Hello")
//
//func someSimpleFunctionWithClosure(closure: () -> () ){
//
//}
//
//------------------------------------
//let arrayWithClosures: [()->()]

//------------------------------------
//
//func finder (array:[Int], completion: ()->(Bool)) -> [Int] {
//    var newArray = [Int]()
//    for i in array {
//        if completion() {
//            if i % 2 == 0 {
//                newArray += [i]
//            }
//            } else {
//                if i % 2 == 1 {
//                newArray += [i]
//            }
//        }
//    }
//
//    return newArray
//}
//
//let array = finder(array: [2, 3, 5, 8, 11, 24]) { () -> (Bool) in
//    return true
//}
//print(array)

//------------------------------------

//let name = "Harut"
//let text = "Hello dear \(name)"
//print(text)


//let label = "The width is "
//let width = 94
//let widthLabel = label + String(width)


//let explicitFloat: Float = 4.0


//var unsortedArray = [3,6,57,45,2,7,9,14,90,-8]
//
//for i in 0..<unsortedArray.count {
//    for j in 1..<unsortedArray.count - i {
//
//    }
//}

//------------------------------------

//enum compassPoint {
//    case north, east, west, south
//}
//
//print("Where are the west side?")
//
//var directionToHead = compassPoint.east
//directionToHead = .west
//
//switch directionToHead {
//case .north:
//    print("Lots of planets have a north")
//case .south:
//    print("Watch out for penguins")
//case .east:
//    print("Where the sun rises")
//case .west:
//    print("Where the skies are blue")
//}

//------------------------------------


//enum SomeMaps {
//    case erangel, miramar, sanhok, karakin, vikendi
//}
//
//print("which map is the best in PUBG")
//
//var theBestMap: SomeMaps
//theBestMap = .erangel
//switch theBestMap {
//case .erangel:
//    print("Erangel is the best map in PUBG")
//default:
//    print("And no one besides Erangel")
//}

//------------------------------------

//enum Drinks: CaseIterable {
//    case coffee, shot, tea, jinn
//}
//
//print("How many drinks are available?")
//
//let numberOfDrinks = Drinks.allCases.count
//print("\(numberOfDrinks) drinks are available")
//
//for drinks in Drinks.allCases {
//    print(drinks)
//}

//-------------------------------------


//enum Student {
//    case name(String), age(Int), course(Int)
//}
//
//var std: Student
//
//std = .name("Armen")
//std = .age(20)
//std = .course(3)
//
//switch std {
//case .name:
//    print("Armen")
//case .age:
//    print("I'm 20 y.o")
//case .course:
//    print("I'm in 3-rd course")
//}
//

//-------------------------------------
//
//let minutes = 60
//let minuteInterval = 5
//for tickMark in stride(from: 0, to: minutes, by: minuteInterval) {
//    print(tickMark)
//}
//

//-------------------------------------

//func finder (array: [Int], completion: ()->(Bool)) -> [Int] {
//    var newArray = [Int]()
//    for i in array {
//        if completion() {
//            if i % 2 == 0 {
//                newArray += [i]
//            }
//        } else {
//            if i % 2 == 1 {
//                newArray += [i]
//            }
//        }
//    }
//    return(newArray)
//}
//
//let array = finder(array: [2,5,67,8,45,44,32,56,97,1]) {
//    return false
//}
//
//print(array)

//-------------------------------------

//func sort (array: [Int], completion: ()->(Bool)) -> [Int] {
//    var newArray = array
//    for i in 0..<newArray.count {
//        for j in 1..<newArray.count - i {
//            if completion() {
//                if newArray[j] < newArray[j-1] {
//                    let tmp = newArray[j-1]
//                    newArray[j-1] = newArray[j]
//                    newArray[j] = tmp
//                }
//            } else {
//                if newArray[j] > newArray[j-1] {
//                    let tmp = newArray[j-1]
//                    newArray[j-1] = newArray[j]
//                    newArray[j] = tmp
//                }
//            }
//        }
//    }
//
//    return(newArray)
//}
//
//let array = sort(array: [5,76,34,89,3,12,3,1,67,33]) {
//    return false
//}
//
//print(array)

//-------------------------------------

//func compare (array1: [Int], array2: [Int]) -> Bool {
//    if array1.count != array2.count {
//        return false
//    }
//    let sortUp = sort(array: array1) { () -> (Bool) in
//        return false
//    }
//    let sortBottom = sort(array: array2) { () -> (Bool) in
//        return false
//    }
//    for i in 0..<sortUp.count {
//        if sortUp[i] != sortBottom[i] {
//            return false
//        }
//    }
//    return true
//}
//
//print(compare(array1: [2,5,6,45,76], array2: [45,5,76,6,2]))

//-------------------------------------

//var shoppingList = ["eggs", "milk", "syrup"]
//
//shoppingList[0] = "six eggs"
//
//shoppingList.append("bread")
//
//shoppingList[1...2] = ["bananas"]
//
//shoppingList.insert("syrup", at: 2)
//
//let sixEggs = shoppingList.remove(at: 0)
//
//print(shoppingList)
//
//for item in shoppingList {
//    print(item)
//}
//for (index, value) in shoppingList.enumerated() {
//    print("Item \(index+1): \(value)")
//}
//
//--------------------------------------------------------------------------------------

//let oddDigits: Set = [1,3,5,7,9]
//let evenDigits: Set = [0,2,4,6,8]
//let singleDigitPrimeNumbers: Set = [2,3,5,7]
//
//print(oddDigits.union(evenDigits).sorted())
//print(oddDigits.intersection(singleDigitPrimeNumbers).sorted())
//print(evenDigits.subtracting(singleDigitPrimeNumbers).sorted())
//print(oddDigits.symmetricDifference(singleDigitPrimeNumbers).sorted())
//
//--------------------------------------------------------------------------------------

//var airports = ["YYZ": "Toronto Pearson", "DUB": "Dublin"]
//
//let softWrappedQuotation = """
//The White Rabbit put on his spectacles. "Where shall I begin, \
//please your Majesty?" he asked.
//
//"Begin at the beginning," the King said gravely, "and go on \
//till you come to the end; then stop."
//"""
//print(softWrappedQuotation)
//--------------------------------------------------------------------------------------

//let wiseWords = "\"Imagination is more important than knowledge\" - Einstein"
//// "Imagination is more important than knowledge" - Einstein
//let dollarSign = "\u{24}" // $, Unicode scalar U+0024
//let blackHeart = "\u{2665}" // ♥, Unicode scalar U+2665
//let sparklingHeart = "\u{1F496}" // 💖, Unicode scalar U+1F496
//
//for character in "Dog!" {
//    print(character)
//}
//
//let catCharacters: [Character] = ["C","a","t","!"]
//let catString = String(catCharacters)
//print(catString)
//
//let http404Error = (404, "Not Found")
//let (statusCode, _/*we can write here statusMessage*/) = http404Error
//print("the status code is \(statusCode)")
//// or we can write
//print("the status message is \(http404Error.1)")
//
//let http200Status = (codeStatus: 200, description: "Ok")
//print("the another status code is \(http200Status.codeStatus)")
//print("the another status message is \(http200Status.description)")

//--------------------------------------------------------------------------------------

//let finalSquare = 25
//var board = [Int](repeating: 0, count: finalSquare + 1)
//
//board[03] = +08; board[06] = +11; board[09] = +09; board[10] = +02
//board[14] = -10; board[19] = -11; board[22] = -02; board[24] = -08
//
//var square = 0
//var diceRoll = 0
//while square < finalSquare {
//    // бросок кубика
//    diceRoll += 1
//    if diceRoll == 7 { diceRoll = 1 }
//    // начать ходить на выпавшее количество шагов
//    square += diceRoll
//    if square < board.count {
//        // если мы все еще на поле, идти вверх или вниз по змеям или лестницам
//        square += board[square]
//    }
//}
//print("Game over!")

//repeat {
//    // идти вверх или вниз по змеям или лестницам
//    square += board[square]
//    // бросить кубик
//    diceRoll += 1
//    if diceRoll == 7 { diceRoll = 1 }
//    // начать ходить на выпавшее количество шагов
//    square += diceRoll
//} while square < finalSquare
//print("Game over!")
//
//var i = 0
//marker : while i<3 {
//    i+=1
//    print("hello")
//}

//gameLoop: while square != finalSquare {
//    diceRoll += 1
//    if diceRoll == 7 {diceRoll = 1}
//    switch square + finalSquare {
//    case finalSquare:
//        print("u win")
//        break gameLoop
//    case let newSquare where newSquare > finalSquare:
//        continue gameLoop
//    default:
//        square += diceRoll
//        square += board[square]
//    }
//}
//print("Game over!!!")

//--------------------------------------------------------------------------------------

//func greet (person: [String: String]) {
//    guard let name = person["name"] else {
//        return
//    }
//    print("Hello \(name)")
//    guard let location = person["location"] else {
//        print("i think in youre area good weather")
//        return
//    }
//    print("i think in \(location) good weather")
//}
//
//greet(person: ["name": "john"])
//greet(person: ["name": "Igor", "location": "Stepanakert"])

//--------------------------------------------------------------------------------------
//
//let names = ["tom", "alex", "bob", "jimmy", "tim"]
//
//func sort (_ s1: String, _ s2: String) ->  Bool {
//    return s1 > s2
//}
//
//var reversedNames = names.sorted(by: { (s1: String, s2: String) -> Bool in
//    return s1 > s2
//})
//
//print(reversedNames)
//
//var sortedNames = names.sorted(by: { s1, s2 in
//    return s1 < s2
//})
//
//print(sortedNames)
//
//var sortedNamesByDollar = names.sorted(by: { $0 > $1 })
//
//print(sortedNamesByDollar)
//
//var yaVAxueUje = names.sorted(by: <)
//
//print(yaVAxueUje)

//--------------------------------------------------------------------------------------

//let digitNames = [
//    0: "zero", 1: "one", 2: "two", 3: "three", 4: "four",
//    5: "five", 6: "six", 7: "seven", 8: "eight", 9: "nine"
//]
//
//var numbers = [50, 12, 456]
//
//let strings = numbers.map { number -> String in
//    var number = number
//    var output = ""
//    repeat {
//        output = digitNames[number % 10]! + output
//        number /= 10
//    } while number > 0
//    return output
//}
//--------------------------------------------------------------------------------------

//var customersInLine = ["Chris", "Alex", "Ewa", "Barry", "Daniella"]
//print(customersInLine.count)
//
//let customerProvider = { customersInLine.remove(at: 0) }
//print(customersInLine.count)
//
//print("Now serving \(customerProvider())!")
//print(customersInLine.count)
//
//func serve (customer customerProvider: @autoclosure () -> String) {
//    print("Now serving \(customerProvider())")
//}
//
//serve(customer: customersInLine.remove(at: 0))
//
//var customerProviders: [() -> String] = []
//func collectCustomerProviders(_ customerProvider: @autoclosure @escaping () -> String) {
//    customerProviders.append(customerProvider)
//}
//
//collectCustomerProviders(customersInLine.remove(at: 0))
//collectCustomerProviders(customersInLine.remove(at: 0))
//print("collected \(customerProviders.count) closures")
//
//for customerProvider in customerProviders {
//    print("now serving \(customerProvider())")
//}
//--------------------------------------------------------------------------------------

//class Counter {
//    var count = 0
//    func increment() {
//        count += 1
//    }
//    func increment(by amount: Int) {
//        count += amount
//    }
//    func reset(){
//        count = 0
//    }
//}
//let counter = Counter()
//counter.increment(by: 6)

//struct Point {
//    var x = 0.0, y = 0.0
//    mutating func moveBy(x deltaX: Double, y deltaY: Double) {
//        x += deltaX
//        y += deltaY
//        self = Point(x: x + deltaX, y: y + deltaY)
//    }
//}
//var somePoint = Point.init(x: 1.0, y: 1.0)
//somePoint.moveBy(x: 3.0, y: 2.0)
//print(somePoint)



//enum Student {
//    case name(String)
//    case age(Int)
//    case course
//}
//
//let st = Student.name("Armen")
//
//print(st)
//
//switch st {
//case .name(let nm):
//    if nm == "Armen" {
//        print(nm)
//    }
//case .age(let ag):
//    print(ag)
//case .course:
//    print("4")
//}
//
//
//enum Year {
//    case winter, summer, autumn, spring
//}
//
//
//func checkYear(_ checkedYear: Year) -> (String){
//    switch checkedYear {
//    case .autumn:
//        return "Autumn"
//    case .spring:
//        return "Spring"
//    case .summer:
//        return "Summer"
//    default:
//        return "Winter"
////  or case .winter:
////      return "Winter"
//    }
//}
//
//let getSeason = checkYear(.autumn)
//
//print(getSeason)
//
//
//enum Colors {
//    case red, blue, green, orange
//}
//
//func getColorNumber (_ checkedColor: Colors) -> Int {
//    switch checkedColor {
//    case .blue:
//        return 0
//    case .green:
//        return 1
//    case .orange:
//        return 2
//    case .red:
//        return 3
//    }
//}
//
//let myChoice = getColorNumber(.green)
//print(myChoice)
//
//enum TriStateSwitch {
//    case off, low, high
//    mutating func next() {
//        switch self {
//        case .off:
//            self = .low
//        case .low:
//            self = .high
//        case .high:
//            self = .off
//        }
//    }
//}
//
//var ovenLight = TriStateSwitch.off
//ovenLight.next()
//ovenLight.next()

//--------------------------------------------------------------------------------------
//
//struct LevelTracker {
//    static var highestUnlockedLevel = 1
//    var currentLevel = 1
//
//    static func unlock(_ level: Int) {
//        if level > highestUnlockedLevel { highestUnlockedLevel = level}
//    }
//
//    static func isUnlocked(_ level: Int) -> Bool {
//        return level <= highestUnlockedLevel
//    }
//
//    @discardableResult mutating func advance(to level: Int) -> Bool {
//        if LevelTracker.isUnlocked(level) {
//            currentLevel = level
//            return true
//        } else {
//            return false
//        }
//    }
//}
//
//class Player {
//    var tracker = LevelTracker()
//    let playerName: String
//    func complete(level: Int) {
//        LevelTracker.unlock(level + 1)
//        tracker.advance(to: level + 1)
//    }
//    init(name: String) {
//        playerName = name
//    }
//}
//
//var player = Player.init(name: "Igor")
//player.complete(level: 1)
//print("next level is: \(LevelTracker.highestUnlockedLevel)")
//
//player = Player.init(name: "Ok")
//if player.tracker.advance(to: 3) {
//    print("u r in \(LevelTracker.highestUnlockedLevel) level")
//} else {
//    print("this level not reached")
//}

//--------------------------------------------------------------------------------------

//struct AudioChannel{
//    static let thresholdLevel = 10
//    static var maxInputLevelForAllChannels = 0
//    var currentLevel: Int = 0 {
//        didSet {
//            if currentLevel > AudioChannel.thresholdLevel {
//                currentLevel = AudioChannel.thresholdLevel
//            }
//            if currentLevel > AudioChannel.maxInputLevelForAllChannels {
//                AudioChannel.maxInputLevelForAllChannels = currentLevel
//            }
//        }
//    }
//}
//
//var leftChannel = AudioChannel()
//var rightChannel = AudioChannel()
//leftChannel.currentLevel = 7
//print("level of left channel is: \(leftChannel.currentLevel)")
//rightChannel.currentLevel = 12
//print("level of right channel is: \(rightChannel.currentLevel)")
//print(AudioChannel.maxInputLevelForAllChannels)

//--------------------------------------------------------------------------------------

//
//struct TesterOfZone {
//    var width: Int
//    var height: Int
//
//    func checkWidthAndHeight() -> String {
//        if width > 500 && width < 800 && height > 700 && height < 1000 {
//            return "this is PC"
//        } else {
//            return "this is tv"
//        }
//    }
//}
//
//var testValueForTester = TesterOfZone(width: 600, height: 1100)
//print(testValueForTester.checkWidthAndHeight())

//--------------------------------------------------------------------------------------

//struct Car {
//    let color: String
//    let model: String
//}
//
//let car1 = Car(color: "blue", model: "ford")
//let car2 = Car(color: "green", model: "mercedes")
//let car3 = Car(color: "pink", model: "daewoo")
//let car4 = Car(color: "dark grey", model: "bmw")
//
//
//struct Human {
//    let name: String
//    let colorOfEyes: String
//    let cars: [Car]
//
//    func carsInfo() {
//        for everyCar in cars {
//            print("model is: \(everyCar.model)")
//            print("color is: \(everyCar.color)")
//        }
//    }
//}
//
//
//struct Building {
//    let floors: Int
//    let address: String
//    let people: [Human]
//
//    func displayNameAndCarsInfo() {
//        for everyHuman in people {
//            print("Name: \(everyHuman.name)")
//            print("Cars: \(everyHuman.carsInfo())")
//            print("\n")
//        }
//    }
//}
//
//let human1 = Human(name: "Igor", colorOfEyes: "dark", cars: [car1, car2] )
//let human2 = Human(name: "parandzem", colorOfEyes: "pink", cars: [car3, car4])
//human1.carsInfo()
//let builder = Building(floors: 2, address: "xrenegoznaetgde Street", people: [human1, human2])
//builder.displayNameAndCarsInfo()

//--------------------------------------------------------------------------------------


//func greet(person: String) -> String {
//    let greeting = "hello, \(person)!"
//    return greeting
//}
//
//print(greet(person: "Anna"))
//
//func anotherGreet(person: String) {
//    print(person)
//}
//
//anotherGreet(person: "Armen")

//--------------------------------------------------------------------------------------
//
//
//func chooseStepFunc (backward: Bool) -> (Int) -> Int {
//    func stepForward (_ input: Int) -> Int { return input + 1 }
//    func stepBackward(_ input: Int) -> Int { return input - 1 }
//    return backward ? stepBackward : stepForward
//}
//
//var currentValue = 3
//let moveNearerToZero = chooseStepFunc(backward: currentValue > 0)
//
//print("counting to zero")
//while (currentValue != 0) {
//    print(currentValue)
//    currentValue = moveNearerToZero(currentValue)
//}

//--------------------------------------------------------------------------------------

//struct TimesTable {
//    let multiplier: Int
//    subscript(index: Int) -> Int {
//        return multiplier * index
//    }
//}
//
//let threeTimesTable = TimesTable(multiplier: 3)
//print(threeTimesTable[6])
//
//var numberOfLegs = ["pauk": 8, "muravej": 6, "pauk2": 2]
//numberOfLegs["ptichka"] = 2

//--------------------------------------------------------------------------------------


//struct Matrix {
//    let rows: Int, columns: Int
//    var grid: [Double]
//    init(rows: Int, columns: Int) {
//        self.rows = rows
//        self.columns = columns
//        grid = Array(repeating: 0.0, count: rows * columns)
//    }
//    func indexIsValid(row: Int, column: Int) -> Bool {
//        return row >= 0 && row <= rows && column >= 0 && column <= columns
//    }
//    subscript (row: Int, column: Int) -> Double {
//        get {
//            assert(indexIsValid(row: row, column: column), "index out of range")
//            return grid[(row * columns) + column]
//        }
//        set {
//            assert(indexIsValid(row: row, column: column), "index out of range")
//            grid[(row * columns) + column] = newValue
//        }
//    }
//}
//
//var matrix = Matrix(rows: 2, columns: 2)
//matrix[0, 1] = 3
//matrix[1, 0] = 2
//
//enum Planet: Int {
//    case mercury = 1, venus, neptune, saturn, mars, venera
//    static subscript(n: Int) -> Planet {
//        return Planet(rawValue: n)!
//    }
//}
//
//let saturn = Planet[4]
//print(saturn)

//--------------------------------------------------------------------------------------

//class MediaItem {
//    var name: String
//    init(name: String) {
//        self.name = name
//    }
//}
//
//class Movie: MediaItem {
//    var director: String
//    init(name: String, director: String) {
//        self.director = director
//        super.init(name: name)
//    }
//}
//class Song: MediaItem {
//    var artist: String
//    init(name: String, artist: String) {
//        self.artist = artist
//        super.init(name: name)
//    }
//}
//
//let library = [
//    Movie(name: "casablanca", director: "Michael Curtiz"),
//    Song(name: "Blue Suede Shoes", artist: "Elvis Presley"),
//    Movie(name: "Citizen Kane", director: "Orson Welles"),
//]
//
//for item in library {
//    if let movie = item as? Movie {
//        print("movie: \(movie.name), dir.: \(movie.director)")
//    } else
//    if let song = item as? Song {
//        print("song: \(song.name), artist: \(song.artist)")
//    }
//}
//
//struct Student {
//    var name: String
//
//    init(name: String) {
//        self.name = name
//    }
//}
//
//var me = Student(name: "Igor")
//var u = me
//u.name = "sergey"
//print(me.name)
//print(u.name)


//class Student {
//    var name: String
//
//    init(name: String) {
//        self.name = name
//    }
//}
//
//var me = Student(name: "Igor")
//var u = me
//u.name = "sergey"
//print(me.name)
//print(u.name)

//struct City {
//    let name: String
//}
//
//
//class Country {
//    let name: String
//    let myCities: [City]
//
//    init(name: String, myCities: [City]) {
//        self.name = name
//        self.myCities = myCities
//    }
//
//    func displayCitiesName() {
//        for i in myCities {
//            print(i.name)
//        }
//    }
//}
//var city1 = City(name: "yerevan")
//var city2 = City(name: "erebuni")
//var myCountry = Country(name: "haystan", myCities: [city1, city2])
//myCountry.displayCitiesName()

//--------------------------------------------------------------------------------------
//
//class Human {
//    var foot: Int = 2
//    var head: Int = 1
//    var hands: Int = 2
//    var mozg: Bool = true
//
//    init() {
//
//    }
//
//    func hasMozg() {
//        print("this guy have Mozg: \(mozg)")
//    }
//}
//

//class Student: Human {
//    var money: Bool = false
//    var freeTime: Int = 0
//
//    init(freeTime: Int) {
//        self.freeTime = freeTime
//    }
//}
//
//var me = Student(freeTime: 1)
//me.money = false
//me.mozg = true
//print(me.freeTime)
//print(me.money)
//print(me.mozg)
//me.hasMozg()

//--------------------------------------------------------------------------------------

//struct Color {
//    var red, green, blue: Double
//    init(red: Double, green: Double, blue: Double) {
//        self.blue = blue
//        self.green = green
//        self.red = red
//    }
//    init(white: Double) {
//        self.blue = white
//        self.green = white
//        self.red = white
//    }
//}
//
//var myColor = Color(red: 0.3, green: 0.5, blue: 0.2)
//var halfGrey = Color(white: 0.5)

//--------------------------------------------------------------------------------------

//struct Size {
//    var width = 0.0, height = 0.0
//}
//
//struct Point {
//    var x = 0.0, y = 0.0
//}
//
//struct Rect {
//    var origin = Point()
//    var size = Size()
//    init() {}
//    init(origin: Point, size: Size) {
//        self.origin = origin
//        self.size = size
//    }
//    init(center: Point, size: Size) {
//        let originX = center.x - (size.width / 2)
//        let originY = center.y - (size.width / 2)
//        self.init(origin: Point(x: originX, y: originY), size: size)
//    }
//
//}
//
//let basicRect = Rect()
//
//let originRect = Rect(origin: Point(x: 2.0, y: 2.0), size: Size(width: 5.0, height: 5.0))
//
//let centerREct = Rect(center: Point(x: 4.0, y: 4.0), size: Size(width: 3.0, height: 3.0))

//--------------------------------------------------------------------------------------

//class Vehicle {
//    var numberofWheels = 0
//    var description: String {
//        return "\(numberofWheels) wheels"
//    }
//}
//
//let vehicle = Vehicle()
//print("vehicle have \(vehicle.description)")
//
//
//
//class Bicycle: Vehicle {
//    override init() {
//        super.init()
//        numberofWheels = 2
//    }
//}
//
//let bicycle = Bicycle()
//print("bicycle have \(bicycle.description)")

//--------------------------------------------------------------------------------------

//class Food {
//    var name: String
//    init(name: String) {
//        self.name = name
//    }
//    convenience init() {
//        self.init(name: "[Unnamed]")
//    }
//}
//
//let meat = Food(name: "bacon")
//
//let mysteryMeat = Food()
//
//class RecipeIngredient: Food {
//    var quantity: Int
//    init(name: String, quantity: Int) {
//        self.quantity = quantity
//        super.init(name: name)
//    }
//    override convenience init(name: String) {
//        self.init(name: name, quantity: 1)
//    }
//}
//
//
//class ShoppingListItem: RecipeIngredient {
//    var purchased = false
//    var description: String {
//        var output = "\(quantity) x \(name)"
//        output += purchased ? " ✔" : " ✘"
//        return output
//    }
//}
//
//let oneMysteryItem = RecipeIngredient()
//let oneBacon = RecipeIngredient(name: "Bacon")
//let sixEggs = RecipeIngredient(name: "Egg", quantity: 6)
//
//var breakfastList = [
//    ShoppingListItem(),
//    ShoppingListItem(name: "bacon"),
//    ShoppingListItem(name: "Egg", quantity: 6)
//]
//
//breakfastList[0].name = "orange juice"
//breakfastList[0].purchased = true
//for item in breakfastList {
//    print(item.description)
//}

/*--------------------------------------------------------------------------------------*/

//let doubleNumber = 12345.0
//let pi = 3.14
//
//if let change = Int(exactly: doubleNumber) {
//    print(change)
//}
//
//let changeTwo = Int(exactly: pi)
//
//if changeTwo == nil {
//    print("nea, pi ne mogu: \(String(describing: changeTwo))")
//}
//
//struct Animal {
//    let species: String
//    init?(species: String) {
//        if species.isEmpty {
//            return nil
//        }
//        self.species = species
//    }
//}
//
//let myAnimal = Animal(species: "giraffe")
//
//if let giraffe = myAnimal {
//    print("так я проверил успешно ли прошла инициализация, плюс удаляем <Optional:> с консоли: \(giraffe.species)")
//}
//
//let noAnimal = Animal(species: "")
//
//if noAnimal == nil {
//    print("here are no animal yet")
//}
//
//enum TemperaturesUnit {
//    case celsius, kelvin, fahrenheit
//    init?(symbol: Character) {
//        switch symbol {
//        case "C":
//            self = .celsius
//        case "K":
//            self = .kelvin
//        case "F":
//            self = .fahrenheit
//        default:
//            return nil
//        }
//    }
//}
//
//let fahrenheit = TemperaturesUnit(symbol: "g")
//
//if fahrenheit != nil {
//    print("this unit of temperature walk succesfully! \nIt's mean thats our initialization go succes")
//} else {
//    print("this struct dont have unit like that")
//}
//
//class Product {
//    let name: String
//    init?(name: String) {
//        if name.isEmpty {
//            return nil
//        }
//        self.name = name
//    }
//}
//
//class CartItem: Product {
//    let quantity: Int
//    init?(name: String, quantity: Int) {
//        if quantity < 1 { return nil }
//        self.quantity = quantity
//        super.init(name: name)
//    }
//}

//class Document {
//    var name: String?
//    init(){}
//    init? (name: String) {
//        if name.isEmpty { return nil }
//        self.name = name
//    }
//}
//
//class AutomaticallyNamedDocument: Document {
//    override init() {
//        super.init()
//        self.name = "[Untitled]"
//    }
//    override init(name: String) {
//        super.init()
//        if name.isEmpty {
//            self.name = "[Untitled]"
//        } else {
//            self.name = name
//        }
//    }
//}
//
//class UntitledDocument: Document {
//    override init() {
//        super.init(name: "[Untitled]")!
//    }
//}

//struct ChessBoard {
//    let boardColors: [Bool] = {
//        var temporaryBoard = [Bool]()
//        var isBlack = false
//        for i in 1...8 {
//            for j in 1...8 {
//                temporaryBoard.append(isBlack)
//                isBlack = !isBlack
//            }
//            isBlack = !isBlack
//        }
//        return temporaryBoard
//    }()
//    func squareIsBlackAt(row: Int, column: Int) -> Bool {
//        return boardColors[(row * 8) + column]
//    }
//}
//
//let board = ChessBoard()
//print(board.squareIsBlackAt(row: 5, column: 3))


//struct BlackJackCard {
//    enum Suit: Character {
//        case spades = "♠", hearts = "♡", diamonds = "♢", clubs = "♣"
//    }
//
//    enum Rank: Int {
//        case two = 2, three, four, five, six, seven, eight, nine, ten
//        case jack, queen, king, ace
//        struct Values {
//            let first: Int, second: Int?
//        }
//        var values: Values {
//            switch self {
//            case .ace:
//                return Values(first: 1, second: 11)
//            case .jack, .king, .queen:
//                return Values(first: 10, second: nil)
//            default:
//                return Values(first: self.rawValue, second: nil)
//            }
//        }
//    }
//    let rank: Rank, suit: Suit
//    var description: String {
//        var output = "suit is \(suit.rawValue)"
//        output += " value is \(rank.values.first)"
//        if let second = rank.values.second {
//            output += " or \(second)"
//        }
//        return output
//    }
//}
//
//let theAceOfSpades = BlackJackCard(rank: .ace, suit: .spades)
//print(theAceOfSpades.description)
//let heartSymbol = BlackJackCard.Suit.hearts.rawValue
//print(heartSymbol)

/*--------------------------------------------------------------------------------------*/

//extension Double {
//    var km: Double { return self * 1000.0 }
//    var m: Double { return self }
//    var cm: Double { return self / 100.0 }
//    var mm: Double { return self / 1000.0 }
//    var ft: Double { return self / 3.28084}
//}
//
//let oneInch = 25.4.mm
//print("один дюйм равно \(oneInch) metres")
//
//let threeFeet = 3.ft
//print("three feet = \(threeFeet) metres")
//
//struct Size {
//    var width = 0.0, height = 0.0
//}
//struct Point {
//    var x = 0.0, y = 0.0
//}
//struct Rect {
//    var origin = Point()
//    var size = Size()
//}
//
//extension Rect {
//    init(center: Point, size: Size) {
//        let originX = center.x - (size.width / 2)
//        let originY = center.y - (size.height / 2)
//        self.init(origin: Point(x: originX, y: originY), size: size)
//    }
//}
//
//let defaultRect = Rect()
//let memberWiseRect = Rect(origin: Point(x: 5.0, y: 2.0), size: Size(width: 4.0, height: 4.0))
//
//let newRectWithExtension = Rect(center: Point(x: 4.0, y: 5.0), size: Size(width: 4.0, height: 3.0))

//extension Int {
//    mutating func square() {
//        self = self * self
//    }
//}
//
//var someInt = 3
//someInt.square()
//
//extension Int {
//    enum Kind {
//        case zero, positiv, negativ
//    }
//    var kind: Kind {
//        switch self {
//        case 0:
//            return .zero
//        case let x where x > 0:
//            return .positiv
//        default:
//            return .negativ
//        }
//    }
//}
//
//
//
//func kindNumbers (_ numbers: [Int]) {
//    for number in numbers {
//        switch number.kind {
//        case .negativ:
//            print("- ", terminator: "")
//        case .positiv:
//            print("+ ", terminator: "")
//        case .zero:
//            print("0 ", terminator: "")
//        }
//    }
//    print("")
//}
//
//kindNumbers([4, 5, 0, -5, 0, 6, -3])


/*--------------------------------------------------------------------------------------*/

//class Vehicle {
//    var currentSpeed = 0.0
//    var description: String {
//        return ("goes with \(currentSpeed) miles an hour.")
//    }
//    func makeNoise() {
//
//    }
//}
//
//let someVehicle = Vehicle()
//print("vehicle: \(someVehicle.description)")
//
//class Bicycle: Vehicle {
//    var hasBasket = false
//}
//
//class Tandem: Bicycle {
//    var numberOfPassengers = 0
//}
//
//let tandem = Tandem()
//tandem.numberOfPassengers = 2
//tandem.currentSpeed = 13.0
//tandem.hasBasket = true
//print("tandem: \(tandem.description)")
//
//
//class Train: Vehicle {
//    override func makeNoise() {
//        print("chu chu")
//    }
//}
//
//let train = Train()
//train.makeNoise()
//
//class Car: Vehicle {
//    var gear = 1
//    override var description: String {
//        return super.description + " Right now be in this gear: \(gear)"
//    }
//}
//
//let car = Car()
//car.gear = 2
//print("car: \(car.description)")
//
//class AutomaticCar: Car {
//    override var currentSpeed: Double {
//        didSet {
//            gear = Int((currentSpeed / 10.0) + 1)
//        }
//    }
//}
//
//let automatic = AutomaticCar()
//automatic.currentSpeed = 35.0
//print("automatic car: \(automatic.description)")
//
//struct Rect {
//    var length: Double
//    var breadth: Double
//
//    var area: Double {
//        get {
//            return length * breadth
//        }
//        set(newArea) {
//            length = newArea / breadth
//        }
//    }
//}
//
//var rect = Rect(length: 4.0, breadth: 3.0)
//print(rect.area)
//
//rect.area = 40


//class CantTouchPrivate {
//    var a: Int
//
//    private var b: Int = 6
//
//    func addTwoInts() -> Int {
//        return a + b
//    }
//
//    init(a: Int) {
//        self.a = a
//    }
//}
//
//let mine = CantTouchPrivate(a: 5)
//print(mine.addTwoInts())


//class Student {
//    private(set) var firstName: String
//    private(set) var lastName: String
//
//    init(firstName: String, lastName: String) {
//        self.firstName = firstName
//        self.lastName = lastName
//    }
//}
//
//var st = Student(firstName: "Igor", lastName: "Astsatryan

//class Account {
//    var capital: Double
//    var rate: Double
//
//    static var usdRate: Double = 69
//
//    init(capital: Double, rate: Double){
//
//        self.capital = capital
//        self.rate = rate
//    }
//
//    func convert() -> Double{
//
//        return capital / Account.usdRate
//    }
//}

//class Account {
//    var capital: Double
//    var rate: Double
//
//    static var usdRate: Double = 69
//
//    init(capital: Double, rate: Double) {
//        self.capital = capital
//        self.rate = rate
//    }
//    
//    func convert() -> Double {
//        return capital / Account.usdRate
//    }
//}
//
//Account.usdRate = 45
//
//var myAcc = Account(capital: 1000, rate: 0.1)
//print(myAcc.convert())













//class Country {
//
//    private let population = 10000
//
//    func primes(n: Int) -> [Int] {
//        var numbers = [Int](2..<n)
//        for i in 0..<n-2 {
//            let prime = numbers[i]
//            guard prime > 0 else {
//                continue
//            }
//            for multiple in stride(from: 2 * prime - 2, to: n - 2, by: prime) {
//                numbers[multiple] = 0
//            }
//        }
//        return numbers.filter({$0 > 0})
//    }
//    func findPrimes(completion: ([Int]) -> ()) {
//        let numbers = primes(n: population)
//        completion(numbers)
//    }
//
//
//}
//
//
//class City: Country {
//    var array = [1, 74, 23, 45, 65, 23, 76, 22, 67, 87, 23, 54, 76, 23, 54, 3]
//    func boyOrGirl() -> Dictionary<Int, Any> {
//        var dict: [Int: String] = [:]
//        for i in array {
//            if i % 2 == 0 {
//                dict[i] = "boy"
//            }
//            if i % 2 == 1 {
//                dict[i] = "girl"
//            }
//        }
//        return dict
//    }
//}
//
//class Region: City {
//    var worker: Int = 100 {
//        willSet{
//            print(newValue)
//        }
//        didSet {
//            print(oldValue)
//        }
//    }
//}
//
//class Test {
//    static func testing() {
//        _ = Region()
//    }
//}
//
//
//var arr = [0, -63, 15, 24, -49, 126, 56]

//
//func checkNumber (_ number: Int) -> Int? {
//    if number % 7 == 0 {
//        return number
//    } else {
//        return nil
//    }
//}
//
//
//for i in arr {
//    let result = checkNumber(i)
//    print(result as Any)
//}
//
//func test(_ intArr: [Int], _ zuyg: Bool = true) {
//    if zuyg == true {
//        for i in intArr {
//            if i % 2 == 0 {
//                print(" ays tivy zuyg e \(i)")
//            }
//        }
//    } else {
//        for i in intArr {
//            if i % 2 == 1 {
//                print(" ays tivy kent e \(i)")
//            }
//        }
//    }
//}
//
//test([0, 63, 15, 24, 11, 49, 126, 56], true)


//func test(_ first: Int, _ second: Int) -> Bool {
//
//    return first % second == 0
////    if first % second == 0 {
////        return true
////    } else {
////        return false
////    }
//}
//
//print(test(6, 2))
//

//func test(zang: [Int], ajman: Bool) -> [Int] {
//    var newArr = zang
//    for i in 0..<newArr.count {
//        for j in 1..<newArr.count - i {
//            if ajman {
//                if newArr[j] < newArr[j - 1] {
//                    let tmp = newArr[j - 1]
//                    newArr[j-1] = newArr[j]
//                    newArr[j] = tmp
//                }
//            } else {
//                if newArr[j] > newArr[j - 1] {
//                    let tmp = newArr[j - 1]
//                    newArr[j - 1] = newArr[j]
//                    newArr[j] = tmp
//                }
//            }
//        }
//    }
//    return newArr
//}

//let z = test(zang: arr, ajman: true)
//print(z)


//func primes(array: [Int]) {
//    for number in array {
//        var isPrimeNumber = true
//        if number <= 2 {
//            isPrimeNumber = false
//        } else {
//            for i in 2..<number {
//                if number % i == 0 {
//                    isPrimeNumber = false
//                }
//            }
//        }
//        if isPrimeNumber {
//            print(number)
//        }
//    }
//}
//
////let a = primes(array: [2,5,4,7,9,8,6,11])
//
//
//func fewElements(array: [Int]) {
//    var checkedDictionary: Dictionary<Int, Int> = [:]
//    for i in 0..<array.count {
//        var count = 0
//        for j in 0..<array.count {
//            if array[i] == array[j] {
//                count += 1
//            }
//        }
//        if count>1 {
//            checkedDictionary[array[i]] = count
//        }
//    }
//    print(checkedDictionary)
//}
//
//fewElements(array: [2,5,4,8,67,90,76,5,8,4,3,6,5,2,4,90,76])
//
//
//func findMin(in array: [Int]) -> Int? {
//    if array.count > 0 {
//        var min = array[0]
//        for i in array {
//            if min > i {
//                min = i
//            }
//        }
//        return min
//    } else {
//        return nil
//    }
//}
//
//
//func findMax(in array: [Int]) -> Int? {
//    if array.count > 0 {
//        var max = array[0]
//        for i in array {
//            if max < i {
//                max = i
//            }
//        }
//        return max
//    } else {
//        return nil
//    }
//}
//
//func minAndMax(_ array: [Int]) {
//    let min = findMin(in: array)
//    let max = findMax(in: array)
//    print("Min is \(min ?? nil). Max is \(max ?? nil) ")
//}
//
//minAndMax([2,5,4,8,67,90])


//______________________________________________________________________________________________
//
//
//func arrayWithClosure(in array: [Int], closure: @escaping () -> (Bool)) -> [Int] {
//    var newArray = [Int]()
//
//    for i in array {
//        if closure() {
//            if i % 2 == 0{
//                newArray.append(i)
//            }
//        } else {
//            if i % 2 == 1 {
//                newArray.append(i)
//            }
//        }
//    }
//    return newArray
//
//}
//
//let array = arrayWithClosure(in: [2,5,4,8,67,90]) {
//    return false
//}
//
//print(array)
//
//func testTwoArrays(in array: [Int], with arrayTwo: [Int]) -> Bool {
//    if array == arrayTwo {
//        return true
//    } else {
//        return false
//    }
//}
//
//print(testTwoArrays(in: [3,5,6,4,7], with: [3,5,6,4,7]))
//
//
//enum Weather {
//    case summer, spring, winter, autumn
//}
//
//func printer(nameOfWeather: Weather) -> String {
//    switch nameOfWeather {
//    case .summer:
//        return "summer"
//    case .spring:
//        return "spring"
//    case .winter:
//        return "winter"
//    case .autumn:
//        return "autumn"
//    }
//}
//
//let test = printer(nameOfWeather: .winter)
//
//print(test)
//
//
//enum Colors {
//    case red, blue, orange, purple
//}
//
//func printColorInt(_ color: Colors) -> Int {
//    switch color {
//    case .red:
//        return 0
//    case .blue:
//        return 1
//    case .orange:
//        return 2
//    case .purple:
//        return 3
//    }
//}
//
//let test2 = printColorInt(.orange)
//
//print(test2)

//
//struct DisplayTvOrPc {
//    var width: Int
//    var height: Int
//
//    func testDisplay() -> String {
//        if width>1120 && width<1960 && height>640 && height<840 {
//            return "PC"
//        } else {
//            return "TV"
//        }
//    }
//}
//
//
//let dsp = DisplayTvOrPc(width: 110, height: 700)
//
//print(dsp.testDisplay())
//
//
//struct Car {
//    var model: String
//    var color: String
//    var date: Int
//
//}
//
//let first = Car(model: "BMW", color: "black", date: 2019)
//let second = Car(model: "Mercedes-Benz", color: "white", date: 2020)
//
//struct Human {
//    var colorOfEyes: String
//    var cars: [Car]
//
//    func displayCarInfo() {
//        for everyCar in cars {
//            print("Model is: \(everyCar.model)")
//            print("Color is: \(everyCar.color)")
//            print("Year: \(everyCar.date)")
//        }
//    }
//}
//
//
//let firstMen = Human(colorOfEyes: "blue", cars: [first,second])
//
//firstMen.displayCarInfo()

//
//struct Square {
//    var a: Double
//
//    func makeres() -> Double{
//        return a*a
//    }
//
//    func paragic() -> Double {
//        return 4*a
//    }
//}
//
//let square = Square(a: 3.5)
//
//print(square.makeres())
//
//
//class Country {
//    var name: String
//    var cities: [City]
//
//    init(nameOfCountry: String, cities: [City]) {
//        self.name = nameOfCountry
//        self.cities = cities
//    }
//
//    func displayCitiesNames() {
//        for i in cities {
//            print(i.name)
//        }
//    }
//}
//
//struct City {
//    var name: String
//}
//
//var cityFirst = City(name: "Gyumri")
//var secondCity = City(name: "erevan")
//
//var first = Country(nameOfCountry: "Armenia", cities: [cityFirst,secondCity])
//
//first.displayCitiesNames()

//
//class People {
//    var age: Int = 18
//    var colorOfEyes: UIColor = .brown
//
//    init(age: Int, colorOfEyes: UIColor) {
//        self.age = age
//        self.colorOfEyes = colorOfEyes
//    }
//
//
//
//}
//
//class Student: People {
//    var course: Int
//    var stipend: Bool
//    var stipendValue: Int
//
//    init(course: Int, stipend: Bool, stipendValue: Int, age:Int, colorOfEyes: UIColor){
//        self.course = course
//        self.stipend = stipend
//        self.stipendValue = stipendValue
//        super.init(age: age, colorOfEyes: colorOfEyes)
//    }
//
//}
//
//var me = Student(course: 3, stipend: false, stipendValue: 0, age: 21, colorOfEyes: .blue)


//class Vehicle {
//    var name: String
//    var ground: Bool
//    var wheels: Int
//
//    init(name: String, ground: Bool, wheels: Int) {
//        self.name = name
//        self.ground = ground
//        self.wheels = wheels
//    }
//
//
//}
//
//
//class Car: Vehicle {
//    var abs: Bool
//
//    init(hasABS: Bool, name: String, ground: Bool, wheels: Int) {
//        self.abs = hasABS
//        super.init(name: name, ground: ground, wheels: wheels)
//    }
//}
//
//class Motorcycle: Vehicle {
//    var seasonForRide: Bool
//
//    init(seasonForRide: Bool, name: String, ground: Bool, wheels: Int){
//        self.seasonForRide = seasonForRide
//        super.init(name: name, ground: ground, wheels: wheels)
//    }
//
//}
//
//class Airplane: Vehicle {
//    var wingsLength: Double
//
//    init(wingsLength: Double, name: String, ground: Bool, wheels: Int){
//        self.wingsLength = wingsLength
//        super.init(name: name, ground: ground, wheels: wheels)
//    }
//}
//
//class Helicopter: Vehicle {
//    var countOfBlades: Int
//
//    init(countOfBlades: Int, name: String, ground: Bool, wheels: Int){
//        self.countOfBlades = countOfBlades
//        super.init(name: name, ground: ground, wheels: wheels)
//    }
//}
//
//class AirBus: Airplane {
//    var seats: Int = 150
//    var price: Double
//
//    init(seats: Int, wingsLength: Double, name: String, ground: Bool, wheels: Int, price: Double) {
//        self.seats = seats
//        self.price = price
//        super.init(wingsLength: wingsLength, name: name, ground: ground, wheels: wheels)
//    }
//
//}
//
//class Boeing: Airplane {
//    var seats: Int = 180
//    var price: Double
//
//    init(seats: Int, wingsLength: Double, name: String, ground: Bool, wheels: Int, price: Double) {
//        self.seats = seats
//        self.price = price
//        super.init(wingsLength: wingsLength, name: name, ground: ground, wheels: wheels)
//    }
//}
//
//var airBus32 = AirBus(seats: 153, wingsLength: 20, name: "AirBus-32(XZ34B)", ground: false, wheels: 14, price: 250.5)
//
//print(airBus32.name)
//print(airBus32.price)


//class Circle {
//    var radius: Double = 10
//    var area: Double {
//        get {
//            return 2 * radius
//        }
//        set(newArea) {
//            radius = newArea / 2
//        }
//    }
//    var cval: Double {
//        return radius * 3.14
//    }
//}

//let r = Circle()
//r.radius = 10
//print(r.area)
//r.area = 20
//print(r.cval)


//class Student {
//    var firstName: String
//    var lastName: String
//
//    init(firstName: String, lastName: String) {
//        self.firstName = firstName
//        self.lastName = lastName
//    }
//
//    var displayName: String {
//        return firstName + " " + lastName
//    }
//
//}
//
//var me = Student(firstName: "Igor", lastName: "Astsatryan")
//print(me.displayName)
//
//
//
//class Employee {
//    var monthlySalary: Int
//
//    init(monthlySalary: Int) {
//        self.monthlySalary = monthlySalary
//    }
//
//    var yearlySalary: Int {
//        get {
//            return 12 * monthlySalary
//        }
//        set(newYearlySalary) {
//            print("New yearly salary is: \(newYearlySalary)")
//            monthlySalary = newYearlySalary / 12
//            print("New monthly salary is: \(monthlySalary)")
//        }
//    }
//
//}
//
//var meSecond = Employee(monthlySalary: 20000)
//
//print(meSecond.yearlySalary)
//meSecond.yearlySalary = 480000
//
//
//class ConvertTemperature {
//    var celsius: Double
//    var fahrenheit: Double
//
//    init(celsius: Double, fahrenheit: Double) {
//        self.celsius = celsius
//        self.fahrenheit = fahrenheit
//    }
//
//    var celsToFahr: Double {
//        get {
//            print("\(celsius)Cº =")
//            return celsius * (9/5) + 32
//        }
//        set(newFahrenheit) {
//            celsius = (newFahrenheit - 32) / 1.8
//            print("\(newFahrenheit)Fº is equal \(celsius)Cº")
//        }
//    }
//
//}
//
//var test = ConvertTemperature(celsius: 35, fahrenheit: 0)
//print(test.celsToFahr)
//test.celsToFahr = 50
//
//class UpOrDown {
//    var value: Int
//
//    init(value: Int) {
//        self.value = value
//    }
//
//    var secondValue: Int = 0 {
//        didSet {
//            print("Old value is \(oldValue)")
//            if secondValue > value {
//                value = secondValue
//                print("New value is \(value)")
//            }
//        }
//    }
//
//}
//
//var number = UpOrDown(value: 5)
//number.secondValue = 7
//number.secondValue = 9
//
//struct Rectangle {
//    var length: Int
//    var height: Int
//
//    lazy var displayArea: Int = {
//        return area()
//    }()
//
//    func area() -> Int {
//        return length * height
//    }
//
//
//}
//
//var rect = Rectangle(length: 5, height: 6)
//
//
//print(rect.displayArea)
//
//class Swap {
//    private var celsius: Int = 5
//
//    var getCelsiusOrConcvert: Int {
//        get {
//            return celsius
//        }
//        set(newCelsius) {
//            print("New value of Celsius: \(celsius)")
//        }
//    }
//}
//
//var c = Swap()
//print(c.getCelsiusOrConcvert)
//c.getCelsiusOrConcvert = 10
//
//
//class Score {
//    private var currentScore: Int = 0
//
//    func increment() -> Int {
//        return currentScore + 1
//    }
//
//    func decrement() -> Int {
//        return currentScore - 1
//    }
//
//    var getCurrentScore: Int {
//        get {
//            return currentScore
//        }
//    }
//
//}
//
//var hghg = Score()
//print(hghg.getCurrentScore)
//
//
//


//class Bottle {
//    private var wat = Water(litre: 3.5)
//
//    func getLitrage() -> Double {
//        return wat.litre
//    }
//
//}
//
//class Water {
//    var litre: Double
//
//    init(litre: Double) {
//        self.litre = litre
//    }
//
//}
//
//var a = Bottle()
//a.getLitrage()
//
//
//final class Computer {
//    private(set) var mother = Motherboard()
//
//    init(mother: Motherboard) {
//        self.mother = mother
//    }
//
//
//}
//
//
//final class Motherboard {
//    private var power: Int = 0
//
//    var getPower: Int {
//        get {
//            return power
//        }
//        set(newPower) {
//            power = newPower
//            print("Updated power is: \(newPower)")
//        }
//    }
//}
//
//
//class Bag {
//    static var count: Int = 5
//
//}
//
//var b = Bag.count
//print(b + 5)
//
//class Square {
//    static func getArea(width: Int, height: Int) -> Int {
//        return width * height
//    }
//}
//
//print(Square.getArea(width: 5, height: 5))
//
//
//class Test {
//    static var a: Int = 6
//
//    static func getValue() -> Int {
//        return a
//    }
//}
//
//print(Test.getValue())
//
//
//class Test2 {
//    static var a: Int {
//        return 5
//    }
//
//    class var b: Int {
//        return 10
//    }
//}
//
//
//
//class Human {
//    var fullName: String
//
//    init(name: String) {
//        fullName = name
//    }
//
//    convenience init(firstName: String, lastName: String) {
////        let full = firstName + " " + lastName
//        self.init(name: "\(firstName) \(lastName)" /* full */)
//    }
//}
//
//var me = Human(firstName: "Igor", lastName: "Astsatryan")
//print(me.fullName)
//
//
//class People {
//    var firstName: String
//    var lastName: String
//
//    required init(first: String, last: String) {
//        firstName = first
//        lastName = last
//    }
//}
//
//class Student: People {
//    var course: Int?
//
//    required init(first: String, last: String) {
//        super.init(first: first, last: last)
//    }
//}
//
//class Math {
//    var a: Int
//    var b: Int?
//
//    init(a: Int, b: Int?) {
//        self.a = a
//        self.b = b
//    }
//
//    func sum() -> Int? {
//        return a + (b ?? 0)
//    }
//}
//
//var h = Math(a: 5, b: 7)
//print(h.sum()!)
//
//class Address {
//    var street: String?
//    var buildNumber: String?
//    var app: String?
//
//    func getAddress() -> String {
//        if let str = street, let build = buildNumber, let a = app {
//            return "\(str)-\(build)-\(a)"
//        } else if let str = street, let build = buildNumber {
//            return "\(str)-\(build)"
//        } else if let str = street {
//            return "\(str)"
//        } else {
//            return "We don't find address"
//        }
//    }
//}
//
//var axaxax = Address()
//axaxax.buildNumber = "54"
//axaxax.app = "6"
//axaxax.street = "asenq te ha"
//print(axaxax.getAddress())
//
//
//enum Gender: String {
//    case male, female
//}
//
//class Human2 {
//    var gender: Gender
//
//    init(yourgender: Gender) {
//        self.gender = yourgender
//    }
//
//    convenience init(name: String?) {
//
//        let nm = name
//
//        switch nm {
//        case "Ani":
//            self.init(yourgender: .female)
//        default:
//            self.init(yourgender: .male)
//        }
//
//    }
//
//}
//
//class Student2: Human2 {
//    var course: Int?
//    var id: Int
//
//    init(course: Int?, id: Int) {
//        self.course = course
//        self.id = id
//        super.init(yourgender: .male)
//    }
//
//    func getInfo() -> String {
//
//        if let new = course {
//            return "\(new)"
//        } else {
//            return "Usanoxy durs e mnacel"
//        }
//        /* //if return type like -> (Any) or (String?)
//        if course != nil {
//            return course as Any // we also can -> (as Any) - (course ?? 0)
//        } else {
//            return "Usanoxy durs e mnacel"
//        }
//        */
//    }
//
//}



//extension Int {
//    var isEven: Bool {
//        return self % 2 == 0
//    }
//
//    func isSquare() -> Self {
//        return self * self
//    }
//}
//
//
//extension String {
//    func convertToCharacter() -> [Character] {
//        var emptyArray: [Character] = []
//        for i in self {
//            emptyArray.append(i)
//        }
//        return emptyArray
//    }
//}
//
//
//var hello = "hello"
//
//print(hello.convertToCharacter())
//
//class Person {
//    var firstName: String = ""
//    var lastName: String = ""
//    init(first: String, last:String) {
//        firstName = first
//        lastName = last
//    }
//}
//
//extension Person {
//    var displayName: String {
//        return firstName + " " + lastName
//    }
//}
//
//var igor = Person(first: "Igor", last: "Astsatryan")
//print(igor.displayName)
//
//
//extension Array where Element == String {
//    func convertToString() {
//        var someStr = String()
//        for i in self {
//            someStr += i
//        }
//    }
//}
//
//var someArr = ["I","g","o","r"]
//someArr.convertToString()
//print(someArr.convertToString())

//
//protocol Study {
//
//    var score: Int { get set }
//    var firstName: String {get}
//    var lastName: String {get}
//    func read()
//
//}
//
//class Student3: Study {
//    var score: Int = 15
//
//    var firstName: String = ""
//
//    var lastName: String = ""
//
//    func read() {
//        print("Name: \(firstName) \(lastName), score: \(score)")
//    }
//}
//
//
//
//protocol ModifyCurrentDay {
//    func currentDayOfWeek() -> String
//    mutating func firstDayOfWeek()
//}
//
//enum DaysOfWeek: String, ModifyCurrentDay {
//    mutating func firstDayOfWeek() {
//        self = .monday
//    }
//
//    case monday, sunday, tuesday, wednesday
//    func currentDayOfWeek() -> String {
//        return self.rawValue
//    }
//
//}
//
//var day = DaysOfWeek.tuesday
//print(day.currentDayOfWeek())
//day.firstDayOfWeek()
//print(day.currentDayOfWeek())
//
//
//enum Box {
//    case small, medium, large
//}
//
//enum Mass {
//    case light, medium, heavy
//}
//
//
//protocol LaptopProtocol {
//    var name: String  { get set }
//    var box: Box { get set }
//    var mass: Mass { get set }
//}
//
//struct Laptop: LaptopProtocol {
//    var name: String
//    var box: Box
//    var mass: Mass
//
//    var description: String {
//        return "\(self.name) \(self.box) \(self.mass)"
//    }
//
//}
//
//protocol LaptopsFilter {
//    var values: [LaptopProtocol] {get set}
//    func filter() -> [LaptopProtocol]
//}
//
//class Laptops: LaptopsFilter {
//    var values: [LaptopProtocol] = [Laptop(name: "a", box: .large, mass: .light),
//                                    Laptop(name: "b", box: .medium, mass: .light),
//                                    Laptop(name: "c", box: .small, mass: .medium),
//                                    Laptop(name: "d", box: .medium, mass: .heavy),
//                                    Laptop(name: "e", box: .large, mass: .medium),
//                                    Laptop(name: "f", box: .small, mass: .heavy)]
//
//    func filter() -> [LaptopProtocol] {
//        return values.filter { $0.mass == .light && $0.box == .large }
//    }
//}
//
//
//
//struct Cookie {
//    var size: Int = 5
//    var hasChocolate: Bool = false
//}
//
//
//class Bakery {
//
//    var delegate: BakeryDelegate?
//
//    func makeCookie() {
//        var cookie = Cookie()
//        cookie.size = 6
//        cookie.hasChocolate = true
//        delegate?.CookieWasBaked(cookie)
//    }
//}
//
//class CookieShop: BakeryDelegate {
//    func CookieWasBaked(_ cookie: Cookie) {
//        print(cookie.size)
//    }
//
//
//}
//
//protocol BakeryDelegate {
//    func CookieWasBaked(_ cookie: Cookie)
//}


//class Taxi {
//    var car: String = ""
//    var name: String = ""
//}
//
//class Client: TaxiDelegate {
//    func foundedTaxi(_ taxi: Taxi) {
//    }
//
//    func callTaxi() {
//        let app = App()
//        app.delegate = self
//        app.findTaxi()
//    }
//}
//
//class App {
//
//    weak var delegate: TaxiDelegate?
//
//    func findTaxi() {
//        let object = Taxi()
//        delegate?.foundedTaxi(object)
//
//    }
//}
//
//protocol TaxiDelegate: AnyObject {
//    func foundedTaxi(_ taxi: Taxi)
//}
//
//var call = Client()
//print(call.callTaxi())

//struct Order {
//    let number: Int
//}
//
//class DeliveringService: OrderHandling {
//    func orderReady(_ order: Order) {
//    }
//
//    func getDelivery() {
//        let res = Restaurant()
//        res.delegate = self
//        res.orderHandle()
//    }
//
//}
//
//class Restaurant {
//    weak var delegate: OrderHandling?
//
//    func orderHandle() {
//        let object = Order(number: 1)
//        delegate?.orderReady(object)
//    }
//}
//
//protocol OrderHandling: AnyObject {
//    func orderReady(_ order: Order)
//}
//
////class Vehicle {
////    var name: String
////    weak var storm: Stormtrooper?
////
////    init(name: String) {
////        self.name = name
////    }
////}
////
////class Stormtrooper {
////    var otherName: String
////    weak var ve: Vehicle?
////
////    init(otherName: String) {
////        self.otherName = otherName
////    }
////}
//
//
//struct Animals {
//    let name: String
//    let age: Int
//}
//
//class FirstClass: FilteringAnimalsProtocol {
//    func choosedAnimals(_ animalName: String) {
//        if let animalAge = animals.first(where: {$0.name == animalName})?.age {
//            print(animalAge)
//        }
//    }
//
//    let animals = [Animals(name: "a", age: 6),
//                   Animals(name: "b", age: 4),
//                   Animals(name: "c", age: 5),
//                   Animals(name: "d", age: 3),
//                   Animals(name: "e", age: 7),
//                   Animals(name: "f", age: 2),]
//
//    func sendAnimal() {
//        let random = Int.random(in: 0..<animals.count)
//        let a = animals[random]
//        let secondClass = SecondClass()
//        secondClass.delegate = self
//        secondClass.chooseAnimal(a)
//
//    }
//
//}
//
//class SecondClass {
//    weak var delegate: FilteringAnimalsProtocol?
//
//    func chooseAnimal(_ animal: Animals) {
//        delegate?.choosedAnimals(animal.name)
//    }
//}
//
//protocol FilteringAnimalsProtocol: AnyObject {
//    func choosedAnimals(_ animals: String)
//}

//class A {
//    func run() {
//        let b = B()
//
//        b.firstSubscribe { (text) in
//            print(text)
//        }
//        b.secondSubscribe { (text) in
//            print(text)
//        }
//        b.send()
//    }
//}
//class B {
//
//    var closureArray: [((String) -> ())?] = []
//
//    func firstSubscribe(closure: @escaping (String) -> ()) {
//        closureArray.append(closure)
//    }
//    func secondSubscribe(closure: @escaping (String) -> ()) {
//        closureArray.append(closure)
//    }
//    func send() {
//        for item in 0..<closureArray.count {
//            closureArray[item]?("barev")
//        }
//    }
//}
//
//var a = A()
//a.run()
//
//
//
//
//var a = "barev"
//a = "paryor"
//let closure = { [a] in
//    print(a)
//
//}
//closure() []
//a = "parlyus"
//closure()
